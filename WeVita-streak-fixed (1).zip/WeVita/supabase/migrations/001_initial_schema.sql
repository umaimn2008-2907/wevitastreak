-- WeVita starter schema. Review and test all policies in a non-production project first.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  role text not null default 'patient' check (role in ('patient','caregiver','doctor')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.medication_schedules (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  dosage_instructions text not null,
  schedule_time text not null,
  start_date date,
  end_date date,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.medication_confirmations (
  id uuid primary key default gen_random_uuid(),
  medication_id uuid not null references public.medication_schedules(id) on delete cascade,
  patient_id uuid not null references public.profiles(id) on delete cascade,
  scheduled_for timestamptz not null,
  status text not null default 'unconfirmed' check (status in ('taken','pending','unconfirmed')),
  confirmed_at timestamptz,
  reported_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  unique (medication_id, scheduled_for)
);

create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references public.profiles(id) on delete cascade,
  doctor_id uuid references public.profiles(id) on delete set null,
  doctor_name text not null,
  specialty text not null default '',
  appointment_at timestamptz not null,
  location text not null default '',
  purpose text not null default '',
  status text not null default 'upcoming' check (status in ('upcoming','completed','cancelled')),
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.medical_documents (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references public.profiles(id) on delete cascade,
  uploaded_by uuid not null references public.profiles(id),
  title text not null,
  document_type text not null default 'other',
  storage_path text not null,
  mime_type text not null,
  size_bytes bigint not null check (size_bytes > 0),
  created_at timestamptz not null default now()
);

create table if not exists public.caregiver_authorizations (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references public.profiles(id) on delete cascade,
  caregiver_id uuid not null references public.profiles(id) on delete cascade,
  permissions jsonb not null default '{"medications":true,"appointments":true,"documents":false,"tasks":true}'::jsonb,
  status text not null default 'pending' check (status in ('pending','active','revoked')),
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  unique (patient_id, caregiver_id)
);

create table if not exists public.follow_up_tasks (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references public.profiles(id) on delete cascade,
  assigned_by uuid references public.profiles(id) on delete set null,
  title text not null,
  description text not null default '',
  due_at timestamptz,
  status text not null default 'pending' check (status in ('pending','completed','cancelled')),
  created_at timestamptz not null default now(),
  completed_at timestamptz
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  message text not null,
  category text not null default 'general',
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.activity_events (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  event_type text not null,
  summary text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_med_schedules_patient on public.medication_schedules(patient_id);
create index if not exists idx_med_confirmations_patient_date on public.medication_confirmations(patient_id, scheduled_for desc);
create index if not exists idx_appointments_patient_date on public.appointments(patient_id, appointment_at);
create index if not exists idx_documents_patient_date on public.medical_documents(patient_id, created_at desc);
create index if not exists idx_followups_patient_due on public.follow_up_tasks(patient_id, due_at);
create index if not exists idx_notifications_user_date on public.notifications(user_id, created_at desc);
create index if not exists idx_activity_patient_date on public.activity_events(patient_id, created_at desc);

-- Helper: current user is the patient, or an active caregiver authorization exists.
create or replace function public.can_view_patient(target_patient uuid)
returns boolean language sql stable security definer set search_path = public
as $$
  select auth.uid() = target_patient
  or exists (
    select 1 from public.caregiver_authorizations ca
    where ca.patient_id = target_patient and ca.caregiver_id = auth.uid() and ca.status = 'active'
  )
  or exists (
    select 1 from public.appointments a
    where a.patient_id = target_patient and a.doctor_id = auth.uid()
  );
$$;

alter table public.profiles enable row level security;
alter table public.medication_schedules enable row level security;
alter table public.medication_confirmations enable row level security;
alter table public.appointments enable row level security;
alter table public.medical_documents enable row level security;
alter table public.caregiver_authorizations enable row level security;
alter table public.follow_up_tasks enable row level security;
alter table public.notifications enable row level security;
alter table public.activity_events enable row level security;

-- Profiles: self can view/update only their own profile. Role assignment should be controlled server-side in production.
create policy "profiles_select_self" on public.profiles for select using (id = auth.uid());
create policy "profiles_update_self" on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());
create policy "profiles_insert_self" on public.profiles for insert with check (id = auth.uid());

-- Patient-owned data: patient and authorized care circle can read; patients can create/update their own records.
create policy "med_schedules_select_authorized" on public.medication_schedules for select using (public.can_view_patient(patient_id));
create policy "med_schedules_insert_patient" on public.medication_schedules for insert with check (patient_id = auth.uid() and created_by = auth.uid());
create policy "med_schedules_update_patient" on public.medication_schedules for update using (patient_id = auth.uid()) with check (patient_id = auth.uid());
create policy "med_schedules_delete_patient" on public.medication_schedules for delete using (patient_id = auth.uid());

create policy "med_confirm_select_authorized" on public.medication_confirmations for select using (public.can_view_patient(patient_id));
create policy "med_confirm_insert_patient" on public.medication_confirmations for insert with check (patient_id = auth.uid() and reported_by = auth.uid());
create policy "med_confirm_update_patient" on public.medication_confirmations for update using (patient_id = auth.uid()) with check (patient_id = auth.uid());

create policy "appointments_select_authorized" on public.appointments for select using (public.can_view_patient(patient_id));
create policy "appointments_insert_patient" on public.appointments for insert with check (patient_id = auth.uid() and created_by = auth.uid());
create policy "appointments_update_patient_or_assigned_doctor" on public.appointments for update using (patient_id = auth.uid() or doctor_id = auth.uid()) with check (patient_id = auth.uid() or doctor_id = auth.uid());
create policy "appointments_delete_patient" on public.appointments for delete using (patient_id = auth.uid());

create policy "documents_select_authorized" on public.medical_documents for select using (public.can_view_patient(patient_id));
create policy "documents_insert_patient" on public.medical_documents for insert with check (patient_id = auth.uid() and uploaded_by = auth.uid());
create policy "documents_delete_patient" on public.medical_documents for delete using (patient_id = auth.uid());

create policy "caregiver_auth_select_participants" on public.caregiver_authorizations for select using (patient_id = auth.uid() or caregiver_id = auth.uid());
create policy "caregiver_auth_patient_insert" on public.caregiver_authorizations for insert with check (patient_id = auth.uid());
create policy "caregiver_auth_patient_update" on public.caregiver_authorizations for update using (patient_id = auth.uid()) with check (patient_id = auth.uid());

create policy "followups_select_authorized" on public.follow_up_tasks for select using (public.can_view_patient(patient_id));
create policy "followups_insert_patient_or_authorized_doctor" on public.follow_up_tasks for insert with check (patient_id = auth.uid() or exists (select 1 from public.appointments a where a.patient_id = follow_up_tasks.patient_id and a.doctor_id = auth.uid()));
create policy "followups_update_patient_or_authorized_doctor" on public.follow_up_tasks for update using (patient_id = auth.uid() or exists (select 1 from public.appointments a where a.patient_id = follow_up_tasks.patient_id and a.doctor_id = auth.uid())) with check (patient_id = auth.uid() or exists (select 1 from public.appointments a where a.patient_id = follow_up_tasks.patient_id and a.doctor_id = auth.uid()));

create policy "notifications_select_self" on public.notifications for select using (user_id = auth.uid());
create policy "notifications_update_self" on public.notifications for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "notifications_insert_self" on public.notifications for insert with check (user_id = auth.uid());

create policy "activity_select_authorized" on public.activity_events for select using (public.can_view_patient(patient_id));
create policy "activity_insert_patient" on public.activity_events for insert with check (actor_id = auth.uid() and (patient_id = auth.uid() or public.can_view_patient(patient_id)));

-- IMPORTANT: Configure a private Storage bucket and equivalent storage.objects policies before live document uploads.
-- Production deployment must additionally harden doctor verification, role assignment, invitation acceptance,
-- authorization revocation, and audit trails. Test policies with separate user accounts before using real data.
